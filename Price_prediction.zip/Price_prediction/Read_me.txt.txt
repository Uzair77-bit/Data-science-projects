Price Prediction using Regression:

This is a tickets pricing monitoring system. It scrapes tickets pricing data periodically and stores it in a database.
 Ticket pricing changes based on demand and time, and there can be significant difference in price.
 We are creating this product mainly with ourselves in mind.
 Users can set up alarms using an email, choosing an origin and destination (cities),
 time (date and hour range picker) choosing a price reduction over mean price, etc